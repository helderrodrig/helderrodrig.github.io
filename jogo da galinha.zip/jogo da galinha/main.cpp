#include <stdio.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/allegro_ttf.h>

int main(int argc, char **argv)
{
   ALLEGRO_DISPLAY *display = NULL;
   ALLEGRO_BITMAP *galo[3];
   ALLEGRO_BITMAP *fox[3];
   bool done = false, draw = true,c1 = false,go = true,gameover = false,jogo = true;
   int x = 0, y = 0,i=0;
   int score=0,s=800,q=0;
   int framecount=0,curframe=0,framedelay=5;
   int framecount2=0,curframe2=0,framedelay2=5;
   float velx,vely,movespeed = 5;
   velx = 0;
   vely = 0;
   
   bool jump = false;
   float jumpspeed = 15;
   int f=50,g=650,h=477,d=10,u=100,p=500,o=0,z=10,w=-20,dinos=-200,anda =1;
   int a,b;
   const float gravity = 1;
   	a=570;
   
   if(!al_init()) {
      fprintf(stderr, "failed to initialize allegro!\n");
      return -1;
   }
 
   display = al_create_display(650, 480);
   if(!display) {
      fprintf(stderr, "failed to create display!\n");
      return -1;
   }
   
  
  al_init_primitives_addon();
  al_install_keyboard();
  al_init_image_addon();
  al_init_font_addon();
  al_init_ttf_addon();
  
   ALLEGRO_FONT *font24 = al_load_font("HARRYP__.ttf",30,0);
  
  ALLEGRO_KEYBOARD_STATE KeyState;
  
  ALLEGRO_TIMER *timer = al_create_timer(1.0 / 60);
  ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
  al_register_event_source(event_queue, al_get_keyboard_event_source());
  al_register_event_source(event_queue, al_get_timer_event_source(timer));
  al_register_event_source(event_queue, al_get_display_event_source(display));
  
  al_start_timer(timer);
  
  galo[0] = al_load_bitmap("galinha3.bmp");
  galo[1] = al_load_bitmap("galinha2.bmp");
  galo[2] = al_load_bitmap("galinha1.bmp");
  
  ALLEGRO_BITMAP *dino = al_load_bitmap("quadridinossauro.bmp");
  al_convert_mask_to_alpha(dino, al_map_rgb(255, 0, 255));

  al_convert_mask_to_alpha(galo[0], al_map_rgb(255, 255, 255));
  al_convert_mask_to_alpha(galo[1], al_map_rgb(255, 255, 255));
  al_convert_mask_to_alpha(galo[2], al_map_rgb(255, 255, 255));

  
  ALLEGRO_BITMAP *menu = al_load_bitmap("tela.bmp");
  
  ALLEGRO_BITMAP *g_o = al_load_bitmap("gameover.bmp");
  al_convert_mask_to_alpha(g_o, al_map_rgb(255, 0, 255));
  
  fox[0] = al_load_bitmap("fox1.bmp");
  fox[1] = al_load_bitmap("fox2.bmp");
  fox[2] = al_load_bitmap("fox3.bmp");

  al_convert_mask_to_alpha(fox[0], al_map_rgb(255, 0, 255));
  al_convert_mask_to_alpha(fox[1], al_map_rgb(255, 0, 255));
  al_convert_mask_to_alpha(fox[2], al_map_rgb(255, 0, 255));
  
  
  ALLEGRO_BITMAP *fox1 = al_load_bitmap("fox.bmp");
  al_convert_mask_to_alpha(fox1, al_map_rgb(255, 0, 255));
  
  ALLEGRO_BITMAP *nuvi = al_load_bitmap("nuvi.bmp");
  al_convert_mask_to_alpha(nuvi, al_map_rgb(255,0,255));
  
  ALLEGRO_BITMAP *cerca = al_load_bitmap("cerca.bmp");
  al_convert_mask_to_alpha(cerca, al_map_rgb(255,0,255));
  
  ALLEGRO_BITMAP *ovo = al_load_bitmap("ovo.bmp");
  al_convert_mask_to_alpha(ovo, al_map_rgb(255,0,255));

  
  while(!done)
  {

	ALLEGRO_EVENT events;
	al_wait_for_event(event_queue, &events);
	  	
	if(events.type == ALLEGRO_EVENT_KEY_DOWN)
	{
	  	switch(events.keyboard.keycode)
	  	{
	  		case ALLEGRO_KEY_ESCAPE:
	  		done = true;
	  		break;
		}
			
	}
	else if(events.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
		done = true; 


   if(jogo)
    {
   	  
   	  al_draw_bitmap(menu, 0, 0, 0);
   	  al_flip_display();
   	  if(events.type == ALLEGRO_EVENT_KEY_DOWN)
	  {
	  	switch(events.keyboard.keycode)
	  	{
	  		case ALLEGRO_KEY_SPACE:
	  			jogo = false;
	  			break;
	  		case ALLEGRO_KEY_G:
	  			c1 = true;
	  			break;
	  		case ALLEGRO_KEY_F:
	  			c1 = false;
	  			break;
		}
			
      }
   	  
	}		
		
	if(!jogo)   
	{	
		if(go)
		{
		
		 
		  if(events.type == ALLEGRO_EVENT_TIMER)
			{
		   		al_get_keyboard_state(&KeyState);
		    	if(al_key_down(&KeyState, ALLEGRO_KEY_RIGHT))
		   		{
		     		x += movespeed;
				}
				else if(al_key_down(&KeyState, ALLEGRO_KEY_LEFT))
		    	{
		     		x -= movespeed;
				}
			    
				if(al_key_down(&KeyState, ALLEGRO_KEY_UP) && jump)
		    	{
		    		vely = -jumpspeed;
		    		jump = false;
				
				}
			
				if(!jump)
				{
					vely += gravity;
				}
		    	else 
		    		vely = 0;
		    
		   
		    	y += vely;
		     
		    	jump = (y + 32 >= h);
		    
		    	if(jump)
		    	{
		    		y = h - 32;
				}
				
				if(++framecount >= framedelay)
				{
					if(++curframe >= 3)
					   curframe=0;
					   
					framecount=0;   
				}
				
				if(++framecount2 >= framedelay2)
				{
					if(++curframe2 >= 3)
					   curframe2=0;
					   
					framecount2=0;   
				}
				
		     	
			}
			  
			al_draw_bitmap(galo[curframe], x,y,0);
			
			
			
			if(go)
			{
				al_flip_display();
			    score++;
			}
			 
		  	al_clear_to_color(al_map_rgb(0,150,255));
			al_draw_bitmap(fox[curframe2], a,430,1);
			al_draw_bitmap(cerca, s,420,0);
			al_draw_bitmap(nuvi,g,f,0);
		    al_draw_filled_rectangle(0,480,1000,470,al_map_rgb(125,255,50));
		    al_draw_textf(font24, al_map_rgb(255,0,0),70,10,ALLEGRO_ALIGN_CENTER, "pontos : %i" , score);
		    al_draw_textf(font24, al_map_rgb(255,0,0),550,10,ALLEGRO_ALIGN_CENTER, "maior ponto : %i" , q);
		    al_draw_bitmap(ovo, u,d,0);
		     al_draw_bitmap(dino, dinos,300,0);
		    
		    if(score > 500)
		    {
		    	al_draw_bitmap(ovo, p,o,0);
		    	o+=3;
		    	if(o > 450 )
				{
					o=10;
					p-=50;
					if(p < 0)
					{
						p=500;
					}
				}
				
			}
			
			if(score > 750)
			{
				al_draw_bitmap(ovo, z,w,1);
				w+=3;
				if(w > 450)
				{
					w=-50;
					z+=80;
					if(z > 650)
					{
						z=10;
					}
				}	
			}
		    
		    if(score > 500)
		    {
		    	dinos+=anda;
		    	if(dinos > 110)
		    	{
		    		anda=-3;
				}
				
				if(dinos < -500)
				{
					anda=1;
				}
				
			}
		    
		    d+=3;
			g-=1;
		    a-=6;
		    s-=6;
				    
			if(a < -20)
			{
				a=650;
			}
			
			if(d > 450 )
			{
				d=10;
				u+=200;
				if(u > 650)
				{
					u=200;
				}
			}
			
			if(s < -15)
			{
				s=800;
			}
			
			if(g < -160)
			{
			  g=700;
			  f+=100;
			  if(f > 150)
				f=50;	
			}
		}
	
		
		if(x > 620)
	      x -= 5;
	    
	    if(x<2)
	      x += 5;
	      
	    if((x > a-15 && x < a+30) && y+10 > 410 || (x > s-15 && x < s+30) && y+10 > 415 || (y < d+10 && y > d) && (x > u-15 && x < u+25) || (y < o+10 && y > o) && (x > p-15 && x < p+25) || (y < w+10 && y > w) && (x > z-15 && x < z+25) || dinos+170 > x)
		{
		  go = false;
		  if(events.type == ALLEGRO_EVENT_KEY_DOWN)
	  	  {
		    switch(events.keyboard.keycode)
	  		 {
	  			case ALLEGRO_KEY_R:
	  				a=650;
	  			    s=800;
	  			    d=100;
	  			    u=10;
	  			    p=10;
	  			    o=450;
	  				x=0;
	  				dinos=-200;
					go = true;
	  				break;
	  			case ALLEGRO_KEY_G:
	  				c1 = true;
	  				break;
	  			case ALLEGRO_KEY_F:
	  				c1 = false;
	  				break;
			}
	      } 	
		}
		
		if(!go)
		 {
		 	if(q < score)
	     	{	
		      q=score;
		
		    }
		 
		   if(!jogo)	
			al_draw_bitmap(g_o,125,150,0);
			
			al_flip_display();
			al_draw_filled_rectangle(0,480,1000,470,al_map_rgb(125,255,50));
			  
			al_draw_bitmap(galo[curframe], x,y,1);
			  
			  
			score=0;
		 }
    }
			
  }
 
   al_destroy_display(display);
   al_destroy_timer(timer);
   al_destroy_event_queue(event_queue);
   al_destroy_font(font24); 
   al_destroy_bitmap(galo[0]);
   al_destroy_bitmap(galo[1]);
   al_destroy_bitmap(galo[2]);
   
 
 
   return 0;
}
